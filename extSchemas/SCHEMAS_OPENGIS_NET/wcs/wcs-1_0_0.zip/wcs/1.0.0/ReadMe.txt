OpenGIS(r) WCS schema version 1.0.0 - ReadMe.txt

-----------------------------------------------------------------------

Changes made to WCS 1.0.0:

  * Updated ReadMe.txt
  * Included OGC-exception.xsd from spec

-- 2007-09-06  Kevin Stegemoller

Changes made to WCS 1.0.0:

  * This set of XML Documents for Web Coverage Service (WCS) Version 1.0.0 
    has been edited to reflect the corrigendum to document OGC 03-065r6 that 
    is specified in document OGC 05-076 plus the corrigendum based on the 
    change requests: 
    OGC 05-068r1 "Store xlinks.xsd file at a fixed location"
    OGC 05-081r2 "Change to use relative paths"

  * Note: check each OGC numbered document for detailed changes.

-- 2005-11-22  Arliss Whiteside

-----------------------------------------------------------------------

The Open Geospatial Consortium, Inc. official schema repository is at
  http://schemas.opengis.net/ .
Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/policies/ .
Additional rights of use are described at
  http://www.opengeospatial.org/legal/ . 

Copyright (c) 2008 Open Geospatial Consortium, Inc. All Rights Reserved.

